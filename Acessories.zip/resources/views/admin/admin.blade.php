@extends('admin.master')
@section('admin_content')
<h1> Hell0 from admin site </h1>
@endsection
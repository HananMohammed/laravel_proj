@extends('anony_layout.master')
@section('content')
<h1>welcome from homepage</h1>
@endsection
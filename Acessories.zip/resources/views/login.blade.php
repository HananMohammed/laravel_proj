@extends('anony_layout.master')
@section('content')
<h1>welcome from login</h1>
@endsection
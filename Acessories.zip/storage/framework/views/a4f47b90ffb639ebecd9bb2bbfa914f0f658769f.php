<?php $__env->startComponent('mail::message'); ?>
# this message from our supplier
<h1> Name: <?php echo e($data['t_name']); ?></h1>
<h2> subject:<?php echo e($data['t_subject']); ?></h2>
<h2> Message is : </h2>
<h3>  <?php echo e($data['t_message']); ?></h3>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/mails/firstmail.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div style="width:500px;margin-left:20%;">
<?php echo Form::open(['url' => 'mail/save' , 'files'=>'true']); ?>

<?php echo e(Form::text('t_name','',['class'=>'form-control' , 'placeholder'=>'name '])); ?>

<?php echo e(Form::text('t_subject','',['class'=>'form-control' , 'placeholder'=>'subject'])); ?>

<?php echo e(Form::textarea('t_message','',['class'=>'form-control' , 'placeholder'=>'message here'])); ?>

<?php echo e(form::submit('send',['class'=>'btn btn-primary' , 'style'=>'margin-left:35%;'])); ?>

</div>
 <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/mail.blade.php ENDPATH**/ ?>
<style>
div{
    width:30%;
    float:right;
     margin-right:30%;
}
img{
     width:60%;height:150px;margin-top:20px; margin-bottom:20px;  border: 2px solid green;
    border-radius: 50%;margin-right:30%;
}

lable{
    color:#900020;font-size:20px;
}
</style>

<?php $__env->startSection('supplier_content'); ?>
<?php if(count($all_data)>0): ?>
<?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div>
<img src="<?php echo e(asset('storage/'.$supplier->supplier_photo)); ?>"style="height:200px;width:200px;border-radius:50%;"/>
<h5>    <lable>  Name : </lable><?php echo e($supplier->supplier_name); ?> </h5>

<h5>  <lable> email :</lable> <?php echo e($supplier->email); ?> </h5>
<h5>   <lable> phone :</lable> <?php echo e($supplier->phone); ?> </h5>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/setting.blade.php ENDPATH**/ ?>
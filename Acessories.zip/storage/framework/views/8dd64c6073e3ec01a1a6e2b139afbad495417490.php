<?php $__env->startSection('admin_content'); ?>
<h1> Hell0 from admin site </h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/admin/admin.blade.php ENDPATH**/ ?>
<style>
.space{
    width:100%;
    height:20px;
}
</style>

<?php $__env->startSection('content'); ?>

<?php echo Form::open(['url' => 'login_supplier/login' , 'files' => true]); ?>

<div class="form-row" style="margin-left:40%;margin-top:50px;">

  <div class="form-group"style="width:50%;">
    <label for="exampleInputEmail1">Email address</label>
    <?php echo e(Form::email('t_email','',['class'=>'form-control','placeholder'=>'user name' ,'style'=>'margin-left:-20%;'])); ?>


    </div>
    <div class="space"></div>
  <div class="form-group" style="width:50%;">
    <label for="exampleInputPassword1" >Password</label>
    <?php echo e(Form::password('t_pass',['class'=>'form-control awesome','placeholder'=>'***********','style'=>'margin-left:-20%;'])); ?>


  </div>
  <div class="space"></div>

  <div class="form-group form-check">
  <?php echo e(Form::submit('login',['class'=>'btn btn-outline-primary'])); ?>

  </div>
  <div class="space"></div>

</div>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/login_supplier.blade.php ENDPATH**/ ?>
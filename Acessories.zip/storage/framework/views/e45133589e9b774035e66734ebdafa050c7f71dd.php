<?php $__env->startSection('supplier_content'); ?>
<?php if(count($items)>0): ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card" style="width:300px;height:auto;float:left;margin-left:2%;margin-top:15px;">
  <img src="<?php echo e(asset('storage/'.$item->item_photo)); ?>" class="card-img-top" alt="..."style="height:250px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
    <h5 class="card-title"><?php echo e($item->price); ?></h5>
    <p class="card-text" style="overflow:hidden;width:100%;height:70px;font-size:16px;"><lable style="color:blue;font-size:18px;font-family:bold;">short description:  </lable><?php echo e($item->short_desc); ?></p>
    <p class="card-text" style="overflow:hidden;width:100%;height:70px;"><lable style="color:blue;font-size:18px;font-family:bold;">full description:  </lable><?php echo e($item->full_desc); ?></p>

    <!----------------------------id for item details to be edit -------------------------------------->
    
 <?php echo Form::open(['url' => 'supplier_items/edit' ,'files'=>true]); ?>


<div style="display:none">  
    <?php echo e(Form::text('t_id',$item->id,['class'=>'form-control' , 'placeholder'=>'search here'])); ?>

</div>
<?php echo e(form::submit('Edit  ',['class'=>'btn btn-primary','style'=>'margin-left:10%;'])); ?>

<?php echo Form::close(); ?>

<!----------------------------id for item details to be edit -------------------------------------->


    <div style="float:right;margin-top:-55px;margin-right:20%;">
<?php echo Form::open(['url' => 'supplier_items/delete' ,'files'=>true]); ?>


<div style="display:none">  
    <?php echo e(Form::text('t_id',$item->id,['class'=>'form-control' , 'placeholder'=>'search here'])); ?>

</div>
<?php echo e(form::submit('delete',['class'=>'btn btn-danger'])); ?>

<?php echo Form::close(); ?>

</div>
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/supplier_items.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>

<?php /**PATH C:\AppServ\www\laravel\Acessories\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
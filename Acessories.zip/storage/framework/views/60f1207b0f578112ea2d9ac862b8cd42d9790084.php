<?php $__env->startSection('content'); ?>
<!--
<div class="form-row" > 
<?php echo Form::open(['url' => 'items/search']); ?>

<div class="form-group" style="margin-left:20%;width:270%;">
<?php echo e(Form::text('t_word','',['class'=>'form-control' , 'placeholder'=>'search here'])); ?>

</div>
<div class="form-group"style="margin-top:-60px;margin-left:350%;">
<?php echo e(form::submit('search',['class'=>'btn btn-primary'])); ?>

</div>
<?php echo Form::close(); ?>

</div>
-->

<?php if(count($items)>0): ?>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card" style="width:300px;height:auto;float:left;margin-left:2%;margin-top:20px;margin-bottom:30px;">
  <img src="<?php echo e(asset('storage/'.$item->item_photo)); ?>" class="card-img-top" alt="..." style="height:250px;">
  <div class="card-body">
    <h5 class="card-title"><?php echo e($item->item_name); ?></h5>
    <h5 class="card-title"><?php echo e($item->price); ?></h5>
    <p class="card-text" style="overflow:hidden;width:100%;height:70px;"><?php echo e($item->short_desc); ?></p>
    <!----------------------------id for item details -------------------------------------->
    <?php echo Form::open(['url' => 'items/more' ,'files'=>true]); ?>


<div style="display:none">  
    <?php echo e(Form::text('t_id',$item->id,['class'=>'form-control' , 'placeholder'=>'search here'])); ?>

</div>
<?php echo e(form::submit('More',['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/items.blade.php ENDPATH**/ ?>
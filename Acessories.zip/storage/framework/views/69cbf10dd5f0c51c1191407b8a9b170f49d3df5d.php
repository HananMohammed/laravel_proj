<?php $__env->startSection('supplier_content'); ?>
<?php if(count($all_data)>0): ?>
<?php $__currentLoopData = $all_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1 style="font-style:11px;color:blue;margin-left:35%;margin-top:10px;">Edit profile Data</h1>
 <div class="space"></div>
<?php echo Form::open(['url' => 'edit_profile/update' , 'files' => true]); ?>

<div class="form-row" style="margin-left:10%;margin-top:50px;" id="mydiv">
<div class="form-group" id="mydiv"> 

  <lable> edit name</lable> <?php echo e(Form::text('supplier_name',$supplier->supplier_name,['class'=>'form-control'])); ?>

    </div>
    <div class="form-group " id="mydiv">
    <lable>phone</lable><?php echo e(Form::text('phone',$supplier->phone,['class'=>'form-control'])); ?>

    </div>
    <br/>
    <div class="form-group" id="mydiv">
    <lable>password</lable> <?php echo e(Form::password('pass',['class'=>'form-control','placeholder'=>$supplier->password])); ?>

    </div>
    <br/>
     <div class="form-group col-md-12"style="margin-left:24%;" id="mydiv">
    <lable style="margin-left:-5%;">photo</lable><?php echo e(Form::file('supplier_photo',['class'=>'form-control-file','style'=>'margin-left:-5%;'])); ?>

    

    </div>
    <div class="form-group col-md-12"style="margin-left:25%;" id="mydiv">
    <?php echo e(Form::submit('Save changes',['class'=>'btn btn-primary','style'=>'margin-left:20%;'])); ?>

    </div>
</div>
 <?php echo Form::close(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<style>
lable{
    color:#087EFC;
    font-family: "Times New Roman", Times, serif;
    font-size:20px;
}
#mydiv{
    width:70%;margin-left:20%;
 }
.space{width:100%;height:30px;}
</style>

<?php echo $__env->make('s_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/edit_profile.blade.php ENDPATH**/ ?>
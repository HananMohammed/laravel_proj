<?php $__env->startSection('content'); ?>
<h1>welcome from homepage</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('anony_layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel\Acessories\resources\views/welcome.blade.php ENDPATH**/ ?>